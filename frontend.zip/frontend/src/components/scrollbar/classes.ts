// ----------------------------------------------------------------------

export const scrollbarClasses = { root: 'mnl__scrollbar__root' };
