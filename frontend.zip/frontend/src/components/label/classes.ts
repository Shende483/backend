// ----------------------------------------------------------------------

export const labelClasses = { root: 'mnl__label__root', icon: 'mnl__label__icon' };
